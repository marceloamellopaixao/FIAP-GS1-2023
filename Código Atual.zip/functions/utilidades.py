from functions.personalizacao import linha
from functions.bd import insere_valor

# Lista de Op��es no Menu:
opcoesMenu = ['[1] - Cadastros', '[2] - Duvidas', '[3] - Doacao', '[0] - Sair']

#  Banco de Dados dos Utilizadores.
bdUsuarios = []

# Banco de Dados do Cadastro
bdAgroindustria = []
bdEmpFertilizante = []
bdProdRural = []
bdResiduoDisp = []
bdTransacao = []

# Banco de Dados de registros.
bdRegistro = []


def user():
    linha()
    print('[               BEM VINDO A SEMEAMOS!              ]')
    linha()

    print()
    print('Antes de iniciarmos, vamos criar um cadastro?')

    newUser = []

    # Nome do Conte�do a adicionar.
    usuario = {'Nome': input('Digite seu nome inicial: ').strip(),
               'Username': input('Digite seu username para logar futuramente: ').strip().lower(),
               'E-mail': input('Digite seu e-mail: ').strip().lower(),
               'Senha': input('Crie sua senha: ').strip(),
               'Confirma Senha': input('Confirme sua senha: ').strip()}

    print()
    while usuario['Confirma Senha'] != usuario['Senha']:
        usuario['Confirma Senha'] = input('As senhas nao correspondem, Confirme sua senha: ')
        print()
    # Esta fun��o insere os dados na lista acima
    bdUsuarios.append(usuario)
    newUser.append(usuario)
    insere_valor('./banco_dados/bdUsuarios.txt', newUser)

    # Imprime um agradecimento ao usu�rio pelo cadastro efetuado.
    print(usuario['Nome'] + ', Obrigado pelas informacoes')
    print()



# Op��es do Menu
def opcoes_menu():
    for i in range(4):
        print(opcoesMenu[i])


def menu():
    linha()
    print('[              MENU INICIAL - SEMEAMOS             ]')
    linha()
    print()

    opcoes_menu()
    print()