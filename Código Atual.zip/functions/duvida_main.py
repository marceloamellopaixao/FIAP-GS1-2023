from functions.personalizacao import linha
def duvidas():
    linha()

