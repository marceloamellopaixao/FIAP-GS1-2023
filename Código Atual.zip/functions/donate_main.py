from functions.personalizacao import linha
def doacao():
    linha()
