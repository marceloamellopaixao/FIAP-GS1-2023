from functions.personalizacao import linha
import time

# Função que verifica se o arquivo é existente
def verifica_arquivo(arquivo, banco):
    with open(str(arquivo), 'r', encoding='utf-8') as file:
        content = file.readlines()
    content = [x.strip('\n') for x in content]

    lenght = len(content)

    if lenght > 0:
        for i in range(lenght):
            banco.append(content[i])


def cria_arquivo(nome_arquivo_ext):
    open(nome_arquivo_ext, 'a+', encoding='utf-8').close()

    # Versão Anterior
    # with open(nome_arquivo_ext, 'w', encoding='utf-8') as file:
    #     file.write()


# Esta função vai ler o arquivo (Banco de dados) no início da execução
def file_reader(bdUsuarios, bdAgroindustria, bdEmpFertilizante, bdProdRural, bdResiduoDisp, bdTransacao, bdRegistro):
    '''
    Esta função irá verificar se os arquivos utilizados como banco de dados estão disponíveis na pasta,
    caso a pasta estiver vazia será criada todas as bases de dados, para que possam ser utilizada.

    O retorno abaixo, faz a conexão da lista com o arquivo .txt:
    :return: bdUsuarios, bdAgroindustria, bdEmpFertilizante, bdProdRural, bdResiduoDisp, bdRegistro
    '''
    try:
        verifica_arquivo('./banco_dados/bdUsuarios.txt', bdUsuarios)
    except FileNotFoundError:
        cria_arquivo('./banco_dados/bdUsuarios.txt')

    try:
        verifica_arquivo('./banco_dados/bdAgroindustria.txt', bdAgroindustria)
    except FileNotFoundError:
        cria_arquivo('./banco_dados/bdAgroindustria.txt')

    try:
        verifica_arquivo('./banco_dados/bdEmpFertilizante.txt', bdEmpFertilizante)
    except FileNotFoundError:
        cria_arquivo('./banco_dados/bdEmpFertilizante.txt')

    try:
        verifica_arquivo('./banco_dados/bdProdRural.txt', bdProdRural)
    except FileNotFoundError:
        cria_arquivo('./banco_dados/bdProdRural.txt')

    try:
        verifica_arquivo('./banco_dados/bdResiduoDisp.txt', bdResiduoDisp)
    except FileNotFoundError:
        cria_arquivo('./banco_dados/bdResiduoDisp.txt')

    try:
        verifica_arquivo('./banco_dados/bdTransacao.txt', bdTransacao)
    except FileNotFoundError:
        cria_arquivo('./banco_dados/bdTransacao.txt')

    try:
        verifica_arquivo('./banco_dados/bdRegistro.txt', bdRegistro)
    except FileNotFoundError:
        cria_arquivo('./banco_dados/bdRegistro.txt')

    finally:
        return bdUsuarios, bdAgroindustria, bdEmpFertilizante, bdProdRural, bdResiduoDisp, bdRegistro


def insere_valor(arquivo, lista_tmp):
    with open(arquivo, 'a+', encoding='utf-8') as file:
        for insert in lista_tmp:
            file.write(str(insert) + '\n')
